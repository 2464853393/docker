#!/bin/bash

jps | grep JournalNode

exit $?
