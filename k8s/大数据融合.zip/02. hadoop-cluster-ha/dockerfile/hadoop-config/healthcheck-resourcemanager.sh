#!/bin/bash

curl $(hostname):8088

exit $?
